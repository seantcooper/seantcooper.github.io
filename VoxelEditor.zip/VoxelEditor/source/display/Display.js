// var PIXEL_RATIO = (function () {
//     var ctx = document.createElement("canvas").getContext("2d"),
//         dpr = window.devicePixelRatio || 1,
//         bsr = ctx.webkitBackingStorePixelRatio ||
//             ctx.mozBackingStorePixelRatio ||
//             ctx.msBackingStorePixelRatio ||
//             ctx.oBackingStorePixelRatio ||
//             ctx.backingStorePixelRatio || 1;

//     return dpr / bsr;
// })();


// createHiDPICanvas = function (w, h, ratio) {
//     if (!ratio) { ratio = PIXEL_RATIO; }
//     var can = document.createElement("canvas");
//     can.width = w * ratio;
//     can.height = h * ratio;
//     can.style.width = w + "px";
//     can.style.height = h + "px";
//     can.getContext("2d").setTransform(ratio, 0, 0, ratio, 0, 0);
//     return can;
// }

var createCanvas = function (color) {
    var _canvas = document.createElement('canvas');
    _canvas.style.position = "fixed";
    _canvas.style.background = color;
    return _canvas;
}


